from django.contrib import admin
from home.models import Contact
admin.site.register(Contact)
# Register your models here.
