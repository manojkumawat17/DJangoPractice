from django.shortcuts import render
from django.http import HttpResponse
from home.models import Contact
# Create your views here.

from home import models
def test(request):
    return HttpResponse("hello world from home app");

def home(request):
    context = { 'name' : 'Manoj', 'contact' : 9769556753 }
    return render(request,'home.html',context);

def index (request):
    #return HttpResponse ("this is my home page (/)")
    return render(request,'home.html')

def project (request):
    #return HttpResponse ("this is my project page (project/)")
    return render(request,'project.html')


def about (request):
    #return HttpResponse ("this is my about page (about/)")
    return render(request,'about.html')

def contact (request):
    #return HttpResponse ("this is my contact page (contact/)")
    if request.method == "POST":
        print("This is post method")
        name=request.POST['name']
        phone = request.POST['phone']
        email = request.POST['email']
        desc = request.POST['desc']
        print(name,phone,email,desc)
        ins = Contact(name=name,email=email,phone=phone, desc=desc)
        ins.save()
        print ("The data has been written to the DB")
    return render(request,'contact.html')
