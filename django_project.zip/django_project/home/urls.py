from django.urls import path
from . import views
from home import views as HomeViews

urlpatterns  = [
    #path('',views.home, name = 'home'),
    path('home/',HomeViews.test, name = 'Manoj'),
    path('home/test',HomeViews.test, name = 'Manoj'),
    path('',HomeViews.index, name = 'Manoj'),
    path('about',HomeViews.about, name = 'about'),
    path('project',HomeViews.project, name = 'project'),
    path('contact',HomeViews.contact, name = 'contact'),
]
